#' Visualisation simple d’une série temporelle
#'
#' Trace la série avec un titre automatique.
#'
#' @param x objet ts
#'
#' @examples
#' x <- ts(rnorm(30), frequency = 12)
#' visualisation_serie(x)
visualisation_serie <- function(x) {
   plot(x, main = "Série temporelle", ylab = "Valeurs")
  }
